package JavaBean;

public class Hod {

    private int hodNo;
    private String password;
    
    private String course;
    
    private String instructor;
    
    public Hod(int hodNo, String password){
    	
    	this.hodNo=hodNo;
    	this.password=password;
    	
    }
    public Hod(int hodNo){
    	
        this.hodNo=hodNo;
    }
    
    //hodNo
    public int getHodNo(){
        return hodNo;
    }
    public void setHodNo(int hodNo){
        this.hodNo = hodNo;
    }
    //password
    public String getPassord()
    {
    return password;
    }
    public void setPassword(String password)
    {
    this.password = password;
    }
    //course
    public String getCourse()
    {
    	return course;
    }
    public void setCourse(String course)
    {
    	this.course = course;
    }
    //instructor
    public String getInstructor()
    {
    	return instructor;
    }
    public void setInstructor(String instructor)
    {
    	this.instructor = instructor;
    }
}