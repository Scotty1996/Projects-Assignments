package JavaBean;

public class Course {

    private int courseNo;
    
    private String courseName;
    
    private int enrollees;
    
    
    public Course(int courseNo, String courseName){
    	
    	this.courseNo=courseNo;
    	this.courseName=courseName;
    	
    }
    //courseNo
    public int getCourseNo(){
        return courseNo;
    }
    public void setCourseNo(int courseNo){
        this.courseNo = courseNo;
    }
    //courseName
    public String getCourseName()
    {
    return courseName;
    }
    public void setCourseName(String courseName)
    {
    this.courseName = courseName;
    }
    //enrollees
    public int getEnrollees()
    {
    	return enrollees;
    }
    public void setEnrollees(int enrollees)
    {
    	this.enrollees = enrollees;
    }
}