package JavaBean;

public class Teacher {

    private int tchNo;
    private String password;
    
    private int pupilNo;

    private String course;
    
    public Teacher(int tchNo, String password){
    	
    	this.tchNo=tchNo;
    	this.password=password;
    	
    }
  
    public Teacher(String course){
    	
    	this.course=course;
    }
    
    public Teacher(int tchNo, int pupilNo){
    	
        this.tchNo=tchNo;
        this.pupilNo=pupilNo;

    }
    
    public Teacher(int tchNo){
    	
        this.tchNo=tchNo;

    }
    //tchNo
    public int getTchNo(){
        return tchNo;
    }
    public void setTchNo(int tchNo){
        this.tchNo = tchNo;
    }
    //password
    public String getPassord(){
    	return password;
    }
    public void setPassword(String password){
    	this.password = password;
    }
    //pupilNo
    public int getPupilNo(){
        return pupilNo;
    }
    public void setPupilNo(int pupilNo){
        this.pupilNo = pupilNo;
    }
    //course
    public String getCourse(){
    	return course;
    }
    public void setCourse(String course){
    	this.course = course;
    }
}