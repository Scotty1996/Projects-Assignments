package JavaBean;

public class Student {

    private int stdNo;
    private String password;
    
    private int quiz1;
    private int quiz2;
    
    private int assignment1;
    private int assignment2;
    private int assignment3;
    
    private int mid;
    private int finals;
    private int total;
    
    private String course;
    
    public Student(int stdNo, String password){
    	
    	this.stdNo=stdNo;
    	this.password=password;
    	
    }

    public Student(String course){
    	
    	this.course=course;
    }
    
    public Student(int stdNo, int quiz1, int quiz2, int assignment1, int assignment2, int assignment3, int mid, int finals, int total){
    	
        this.stdNo=stdNo;
        this.quiz1=quiz1;
        this.quiz2=quiz2;
        this.assignment1=assignment1;
        this.assignment2=assignment2;
        this.assignment3=assignment3;
        this.mid=mid;
        this.finals=finals;
        this.total=total;
    }
    //stdNo
        public int getStdNo()
    {
        return stdNo;
    }

    public void setStdNo(int stdNo)
    {
        this.stdNo = stdNo;
    }
    //password
    public String getPassord()
    {
    return password;
    }
    public void setPassword(String password)
    {
    this.password = password;
    }
    //quiz1
        public int getQuiz1()
    {
        return quiz1;
    }
    public void setQuiz1(int quiz1)
    {
        this.quiz1 = quiz1;
    }
    //quiz2
    public int getQuiz2()
    {
    return quiz2;
    }
    public void setQuiz2(int quiz2)
    {
    this.quiz2 = quiz2;
    }
    //assignment1
    public int getAssignment1()
    {
        return assignment1;
    }
    public void setAssignment1(int assignment1)
    {
        this.assignment1 = assignment1;
    }
    //assignment2
    public int getAssignment2()
    {
        return assignment2;
    }
    public void setAssignment2(int assignment2)
    {
        this.assignment2 = assignment2;
    }
    //assignment3
    public int getAssignment3()
    {
        return assignment3;
    }
    public void setAssignment3(int assignment3)
    {
        this.assignment3 = assignment3;
    }
    //mid
    public int getMid()
    {
        return mid;
    }
    public void setMid(int mid)
    {
        this.mid = mid; //mid worth 40%
    }
    //finals
    public int getFinals()
    {
        return finals;
    }
    public void setFinals(int finals)
    {
        this.finals = finals; //finals worth 60%
    }
    //total
        public int getTotal()
    {
        return total;
    }
    public void setTotal(int total)
    {
        this.total = total;
    }
    //course
    public String getCourse()
    {
    	return course;
    }
    public void setCourse(String course)
    {
    	this.course = course;
    }
}