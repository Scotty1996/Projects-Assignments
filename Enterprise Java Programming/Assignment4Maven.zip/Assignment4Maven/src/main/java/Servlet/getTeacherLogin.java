package Servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
//import jakarta.servlet.http.HttpSession;


import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import JavaBean.Teacher;

/**
 * Servlet implementation class getStudent
 */
@SuppressWarnings("serial")
@WebServlet(name = "getTeacher", urlPatterns = {"/getTeacher"})
public class getTeacherLogin extends HttpServlet {
	//private static final long serialVersionUID = 1L;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    		
        ArrayList<Teacher> teacher = new ArrayList<>();
        
        String teacherID = request.getParameter("username");
        String teacherPassword = request.getParameter("password");
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Teacher.class.getName()).log(Level.SEVERE, null, ex);
        }
        try
        {
            String dbURL = "jdbc:mysql://localhost:3306/assignment4mysql";
            String username = "root";
            String password = "scott96";


            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select idteacher, pwd from teacher");
                System.out.println("rs = " + rs.toString());
                while (rs.next())
                {

                    int tchNo = rs.getInt("idteacher");
                    String pwd = rs.getString("pwd");

                    Teacher t = new Teacher(tchNo, pwd);
                    teacher.add(t);

                }
            }
        } catch (SQLException e)
        {
                System.out.println("SQLException: " + e.toString());
        }
        try {
        	
       
	        for(Teacher elements: teacher) {
	        	
	        	if(teacherID.equals(String.valueOf(elements.getTchNo())) && teacherPassword.equals(elements.getPassord())){	        		
	
	        		ServletContext context=getServletContext();  
	        		context.setAttribute("login", teacherID);  
	        	
	                RequestDispatcher dispatcher = request.getRequestDispatcher("getTeacher");
	                dispatcher.forward(request, response);
	                
	        	}
	        }
        }catch(Exception e) {
        	
	        RequestDispatcher dispatcher = request.getRequestDispatcher("WebPage/HTML/TeacherLogin.html");
	        dispatcher.forward(request, response);
        
        }
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("WebPage/HTML/TeacherLogin.html");
        dispatcher.forward(request, response);
        
    }
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
    	processRequest(request, response);
	}
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		processRequest(request, response);
	}
    @Override
    public String getServletInfo() {
    	return "Short description";
    }
}