package Servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import JavaBean.Course;
import JavaBean.Student;

/**
 * Servlet implementation class getStudent
 */
@SuppressWarnings("serial")
@WebServlet(name = "getStudent", urlPatterns = {"/getStudent"})
public class getStudent extends HttpServlet {
	//private static final long serialVersionUID = 1L;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
        ArrayList<Student> student = new ArrayList<>();
        ArrayList<Student> studentCourse = new ArrayList<>();
        ArrayList<Course> course = new ArrayList<>();
        
        ServletContext context=getServletContext();  
        String id=(String)context.getAttribute("login");  
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
        try
        {
            String dbURL = "jdbc:mysql://localhost:3306/assignment4mysql";
            String username = "root";
            String password = "scott96";


            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select idstudent, quiz1, quiz2, assignment1, assignment2, assignment3, mid, final, total from student where idstudent = " + id);
                System.out.println("rs = " + rs.toString());
                while (rs.next())
                {

                    int stdNo = rs.getInt("idstudent");
                    int quiz1 = rs.getInt("quiz1");
                    int quiz2 = rs.getInt("quiz2");
                    int assignment1 = rs.getInt("assignment1");
                    int assignment2 = rs.getInt("assignment2");
                    int assignment3 = rs.getInt("assignment3");
                    int mid = rs.getInt("mid");
                    int finals = rs.getInt("final");
                    int total = rs.getInt("total");

                    Student s = new Student(stdNo, quiz1, quiz2 , assignment1, assignment2, assignment3, mid, finals, total);
                    student.add(s);

                }
            }
            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select courseName from course c, student s where c.idcourse = s.courseNo and s.idstudent = " + id);
                System.out.println("rs = " + rs.toString());
                while (rs.next())
                {

                    String courseName = rs.getString("courseName");
  
                    Student c = new Student(courseName);
                    studentCourse.add(c);

                }
            }
            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select idcourse, courseName from course");
                System.out.println("rs = " + rs.toString());
                while (rs.next())
                {

                    int courseNo = rs.getInt("idcourse");
                    String courseName = rs.getString("courseName");

                    Course c = new Course(courseNo, courseName);
                    course.add(c);

                }
            }
        } catch (SQLException e)
        {
                System.out.println("SQLException: " + e.toString());
        }

        HttpSession sessionGrades = request.getSession();
        sessionGrades.setAttribute("grade", student);
        
        HttpSession sessionCourse = request.getSession();
        sessionCourse.setAttribute("course", studentCourse);
        
        HttpSession sessionRegister = request.getSession();
        sessionRegister.setAttribute("registerCourse", course);

        RequestDispatcher dispatcher = request.getRequestDispatcher("WebPage/JSP/Student.jsp");
        dispatcher.forward(request, response);
    }
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
    	processRequest(request, response);
	}
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		processRequest(request, response);
	}
    @Override
    public String getServletInfo() {
    	return "Short description";
    }
}
