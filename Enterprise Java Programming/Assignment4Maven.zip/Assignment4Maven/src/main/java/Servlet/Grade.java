package Servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import JavaBean.Teacher;
import JavaBean.Student;

/**
 * Servlet implementation class getStudent
 */
@SuppressWarnings("serial")
@WebServlet(name = "Grade", urlPatterns = {"/Grade"})
public class Grade extends HttpServlet {
	//private static final long serialVersionUID = 1L;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	String sid = request.getParameter("sid");
    	String q1 = request.getParameter("q1");
    	String q2 = request.getParameter("q2");
    	String a1 = request.getParameter("a1");
    	String a2 = request.getParameter("a2");
    	String a3 = request.getParameter("a3");
    	
    	System.out.println(q1);
    	
    	int Q1 = Integer.valueOf(q1);int Q2 = Integer.valueOf(q2);
    	int A1 = Integer.valueOf(a1);int A2 = Integer.valueOf(a2);int A3 = Integer.valueOf(a3);
    	
    	System.out.println(Q1);
    	System.out.println(Q2);
    	
    	double midR = (((double)Q1 + (double)Q2)/200)*100;
    	double finalR = (((double)A1 + (double)A2 + (double)A3)/300)*100;
    	int totalR = (int)(midR*0.4) + (int)(finalR*.6);
    	
    	System.out.println(midR);
    	System.out.println(finalR);
    	System.out.println(totalR);
    	
        ArrayList<Teacher> teacher = new ArrayList<>();
        ArrayList<Teacher> teacherCourse = new ArrayList<>();
        ArrayList<Student> student = new ArrayList<>();
        
        ServletContext context=getServletContext();  
        String id=(String)context.getAttribute("login");  
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Teacher.class.getName()).log(Level.SEVERE, null, ex);
        }
        try
        {
            String dbURL = "jdbc:mysql://localhost:3306/assignment4mysql";
            String username = "root";
            String password = "scott96";
            
            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                statement.executeUpdate("update student set quiz1 = " + q1 + " , quiz2 = " + q2 +
                		" , assignment1 = " + a1 + " , assignment2 = " + a2 + " , assignment3 = " + a3 +
                		" , mid = " + midR + " , final = " + finalR + " , total = " + totalR +
                		" where idstudent = " + sid);
            
            }

            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select idTeacher, pupilNo from teacher where idTeacher = " + id );
                System.out.println("rs = " + rs.toString());
                while (rs.next())
                {

                    int tchNo = rs.getInt("idteacher");
                    int pupilNo = rs.getInt("pupilNo");

                    Teacher t = new Teacher(tchNo, pupilNo);
                    teacher.add(t);

                }
            }
            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select courseName from course c, teacher t where c.idcourse = t.courseNo and t.idteacher = " + id);
                System.out.println("rs = " + rs.toString());
                while (rs.next())
                {

                    String course = rs.getString("courseName");
  
                    Teacher c = new Teacher(course);
                    teacherCourse.add(c);

                }
            }
            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select idstudent, quiz1, quiz2, assignment1, assignment2, assignment3, mid, final, total from student");
                System.out.println("rs = " + rs.toString());
                while (rs.next())
                {

                    int stdNo = rs.getInt("idstudent");
                    int quiz1 = rs.getInt("quiz1");
                    int quiz2 = rs.getInt("quiz2");
                    int assignment1 = rs.getInt("assignment1");
                    int assignment2 = rs.getInt("assignment2");
                    int assignment3 = rs.getInt("assignment3");
                    int mid = rs.getInt("mid");
                    int finals = rs.getInt("final");
                    int total = rs.getInt("total");

                    Student s = new Student(stdNo, quiz1, quiz2 , assignment1, assignment2, assignment3, mid, finals, total);
                    student.add(s);

                }
            }
        } catch (SQLException e)
        {
                System.out.println("SQLException: " + e.toString());
        }

        HttpSession sessionGrades = request.getSession();
        sessionGrades.setAttribute("info", teacher);
        
        HttpSession sessionCourse = request.getSession();
        sessionCourse.setAttribute("course", teacherCourse);
        
        HttpSession sessionStudent = request.getSession();
        sessionStudent.setAttribute("student", student);

        RequestDispatcher dispatcher = request.getRequestDispatcher("WebPage/JSP/Teacher.jsp");
        dispatcher.forward(request, response);
    }
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
    	processRequest(request, response);
	}
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		processRequest(request, response);
	}
    @Override
    public String getServletInfo() {
    	return "Short description";
    }
}
