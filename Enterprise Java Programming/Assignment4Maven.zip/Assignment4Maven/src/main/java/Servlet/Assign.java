package Servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import JavaBean.Hod;
import JavaBean.Teacher;
import JavaBean.Course;

/**
 * Servlet implementation class getStudent
 */
@SuppressWarnings("serial")
@WebServlet(name = "Assign", urlPatterns = {"/Assign"})
public class Assign extends HttpServlet {
	//private static final long serialVersionUID = 1L;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	String cid = request.getParameter("cid");
    	String tid = request.getParameter("tid");
    	
        ArrayList<Hod> hod = new ArrayList<>();
        ArrayList<Teacher> teacher = new ArrayList<>();
        ArrayList<Teacher> teacherCourse = new ArrayList<>();
        ArrayList<Course> course = new ArrayList<>();
        
        ServletContext context=getServletContext();  
        String id=(String)context.getAttribute("login");  
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Hod.class.getName()).log(Level.SEVERE, null, ex);
        }
        try
        {
            String dbURL = "jdbc:mysql://localhost:3306/assignment4mysql";
            String username = "root";
            String password = "scott96";
            
            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                statement.executeUpdate("update teacher set courseNo = " + cid + " where idteacher = " + tid);
            
            }


            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select idhod from hod where idhod = " + id );
                System.out.println("rs = " + rs.toString());
                while (rs.next())
                {

                    int hodNo = rs.getInt("idhod");

                    Hod h = new Hod(hodNo);
                    hod.add(h);

                }
            }
            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select idteacher, courseName from course c, teacher t where c.idcourse = t.courseNo");
                System.out.println("rs = " + rs.toString());
                while (rs.next())
                {

                    int tchNo = rs.getInt("idteacher");
                    String courseName = rs.getString("courseName");

                    Teacher t = new Teacher(tchNo);
                    teacher.add(t);
                    
                    Teacher c = new Teacher(courseName);
                    teacherCourse.add(c);

                }
            }
            try (Connection connection = DriverManager.getConnection(dbURL, username, password)) {
                System.out.println("connection = " + connection.toString());
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery("select idcourse, courseName from course");
                System.out.println("rs = " + rs.toString());
                while (rs.next())
                {

                    int courseNo = rs.getInt("idcourse");
                    String courseName = rs.getString("courseName");

                    Course c = new Course(courseNo, courseName);
                    course.add(c);

                }
            }
        } catch (SQLException e)
        {
                System.out.println("SQLException: " + e.toString());
        }

        HttpSession sessionGrades = request.getSession();
        sessionGrades.setAttribute("info", hod);
        
        HttpSession sessionTeacher = request.getSession();
        sessionTeacher.setAttribute("teacher", teacher);
        
        HttpSession sessionTeacherCourse = request.getSession();
        sessionTeacherCourse.setAttribute("teacherCourse", teacherCourse);
        
        HttpSession sessionCourse = request.getSession();
        sessionCourse.setAttribute("assignCourse", course);

        RequestDispatcher dispatcher = request.getRequestDispatcher("WebPage/JSP/Hod.jsp");
        dispatcher.forward(request, response);
    }
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
    	processRequest(request, response);
	}
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		processRequest(request, response);
	}
    @Override
    public String getServletInfo() {
    	return "Short description";
    }
}
