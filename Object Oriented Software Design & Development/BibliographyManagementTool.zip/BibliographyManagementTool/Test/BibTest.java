import org.junit.jupiter.api.Test;
import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static java.util.regex.Pattern.*;
import static org.junit.jupiter.api.Assertions.*;

public class BibTest {

    /**
     * Generic set test
     */
    @Test
    public void testDOI() {

        Article testDOI = new Article();
        testDOI.setDOI("https://doi.org/10.1007/3-540-47910-4_21");
        assertEquals("https://doi.org/10.1007/3-540-47910-4_21", testDOI.getDOI());
    }

    /**
     * Test doi prefix
     */
    @Test
    public void testDOIPrefix(){

        Article testDOI = new Article();
        testDOI.setDOI("https://doi.org/10.1007/3-540-47910-4_21");

        assertTrue(testDOI.getDOI().startsWith("https://doi.org/"));
    }

    /**
     * Test doi center pattern
     */
    @Test
    public void testDOICenterPattern(){

        Article testDOI = new Article();
        testDOI.setDOI("https://doi.org/10.1007/3-540-47910-4_21");

        Pattern pattern = compile("\\d\\d.\\d\\d\\d\\d");
        Matcher matcher = pattern.matcher(testDOI.getDOI().substring(16).split("/")[0]);
        assertTrue(matcher.matches());
    }

    /**
     * Test doi structure - not including prefix
     */
    @Test
    public void testDOIStructure(){

        Article testDOI = new Article();
        testDOI.setDOI("https://doi.org/10.1007/3-540-47910-4_21");

        assertEquals(2, testDOI.getDOI().substring(16).split("/").length);
    }

    /**
     * Test if file can be loaded - file must exist
     */
    @Test
    public void testFileLoad() {

        File fileLoaded = new File("test.txt");

        assertTrue(fileLoaded.exists());

    }
    /**
     * Test if a file can be read - file must exist
     */
    @Test
    public void testFileRead(){

        File fileLoaded = new File("test.txt");

        assertTrue(fileLoaded.canRead());

    }
}
