/**
 * Subclass of Publication
 * Contains unique data members w/ getters and setters
 * Contains type safe process methods used for article items
 */
public class Article extends Publication {

    //Data members
    private String journal;
    private String doi;

    //Setter
    public void setJournal(String journal) {

        this.journal=journal;
    }
    //Setter
    public void setDOI(String doi) {

        this.doi=doi;
    }
    //Getter
    public String getJournal() {

        return journal;
    }
    //Getter
    public String getDOI() {

        return doi;
    }
    //Returns element to Create method
    @Override
    protected void ProcessDisplay(ConcreteFactory displayArticleItem) {
        displayArticleItem.DisplayArticleItem(this);
    }
    @Override
    protected void ProcessInput(ConcreteFactory newArticleInput){
        newArticleInput.InputArticleItem(this);
    }
    @Override
    protected void ProcessSave(ConcreteFactory saveArticleItem) {
        saveArticleItem.SaveArticleItem(this);
    }
    @Override
    protected void ProcessLoad(ConcreteFactory loadArticleItem) {
        loadArticleItem.LoadArticleItem(this);
    }
}