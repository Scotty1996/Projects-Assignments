import java.util.ArrayList;

public class Database {

    private ArrayList<Publication> publications = new ArrayList<>();

    /**
     * Get publication ArrayList
     * @return
     */
    public ArrayList<Publication> getPublications() {
        return publications;
    }

    /**
     * set publication ArrayList
     * @param publications
     */
    public void setPublications(ArrayList<Publication> publications) {
        this.publications = publications;
    }
}
