/**
 * Abstract super class of publication types
 * Contains common data members w/ getters and setter
 * Contains protected abstract methods to direct control to correct subtype
 */
public abstract class Publication {

    //Data members
    protected String citekey;
    protected String author;
    protected String title;
    protected int year;

    //Allows correct access to subclass methods
    protected abstract void ProcessInput(ConcreteFactory processInput);
    protected abstract void ProcessSave(ConcreteFactory processSave);
    protected abstract void ProcessDisplay(ConcreteFactory processItem);
    protected abstract void ProcessLoad(ConcreteFactory processLoad);


    //Setter
    public void setAuthor(String author) {

        this.author=author;
    }
    //Setter
    public void setTitle(String title) {

        this.title=title;
    }
    //Setter
    public void setYear(int year) {

        this.year=year;
    }
    //Getter
    public String getAuthor() {

        return author;
    }
    //Getter
    public String getTitle() {

        return title;
    }
    //Getter
    public int getYear() {

        return year;
    }

    /**
     * SPECIAL KEYS
     */
    //Setter
    public void setCiteKey(String citekey) {

        this.citekey=citekey;
    }
    //Getter
    public String getCitekey() {

        return citekey;
    }
}