/**
 * Subclass of Publication
 * Contains unique data members w/ getters and setters
 * Contains type safe process methods used for report items
 */
public class Report extends Publication {

    //Data members
    private String institution;

    //Setter
    public void setInstitution(String institution) {

        this.institution=institution;
    }
    //Getter
    public String getInstitution() {

        return institution;
    }
    //Returns element to Create method
    @Override
    protected void ProcessDisplay(ConcreteFactory displayReportItem) {
        displayReportItem.DisplayReportItem(this);
    }
    @Override
    protected void ProcessInput(ConcreteFactory newReportInput){
        newReportInput.InputReportItem(this);
    }
    @Override
    protected void ProcessSave(ConcreteFactory saveReportItem) {
        saveReportItem.SaveReportItem(this);
    }
    @Override
    protected void ProcessLoad(ConcreteFactory loadReportItem) {
        loadReportItem.LoadReportItem(this);
    }
}