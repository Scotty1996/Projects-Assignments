/**
 * All methods below are used to direct control to the correct publication subtype
 */
public interface Control {

    void LoadBookItem(Book book);
    void LoadArticleItem(Article article);
    void LoadReportItem(Report report);

    void SaveBookItem(Book book);
    void SaveArticleItem(Article article);
    void SaveReportItem(Report report);

    void InputBookItem(Book book);
    void InputArticleItem(Article article);
    void InputReportItem(Report report);

    void DisplayBookItem(Book book);
    void DisplayArticleItem(Article article);
    void DisplayReportItem(Report report);
}
