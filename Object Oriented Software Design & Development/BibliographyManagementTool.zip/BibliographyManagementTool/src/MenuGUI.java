import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.io.*;
import java.util.ArrayList;

public class MenuGUI extends JFrame implements ActionListener {

    //Data members
    static JTabbedPane addType;
    static JTabbedPane removeType;

    static JButton loadButton; static JButton saveButton;
    static JButton addBookButton; static JButton addArticleButton; static JButton addReportButton;
    static JButton removeBookButton; static JButton removeArticleButton; static  JButton removeReportButton;
    static JButton displayButton;

    static JTextField loadInput; static JTextField saveInput;
    static JTextField addAuthorBook; static JTextField addTitleBook; static JTextField addYearBook; static JTextField addPublisherBook;
    static JTextField addAuthorArticle; static JTextField addTitleArticle; static JTextField addYearArticle; static JTextField addJournalArticle; static JTextField addDOIArticle;
    static JTextField addAuthorReport; static JTextField addTitleReport; static JTextField addYearReport; static JTextField addInstitutionReport;
    static JTextField removeBookKey; static JTextField removeArticleKey; static JTextField removeReportKey;

    static TextArea loadText; static TextArea saveText; static TextArea addText; static TextArea removeText; static TextArea displayText;

    Database database;

    public MenuGUI(){

        this.database = new Database();

    }

    /**
     * Adds 1 type of each publication to database ArrayList for testing
     * @param testList
     */
    public void AddTestList(ArrayList<Publication> testList){

        database.setPublications(testList);

    }

    /**
     * Creates the main display window
     */
    public static void createWindow() {
        JFrame mainFrame = new JFrame("Bibliography Management Tool");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        createUI(mainFrame);
        mainFrame.setSize(500, 500);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    /**
     * Creates the internal layout, design and function of the application
     * @param mainFrame
     */
    public static void createUI(final JFrame mainFrame){

        //Instances
        loadInput = new JTextField(); saveInput = new JTextField();
        addAuthorBook = new JTextField(); addTitleBook = new JTextField(); addYearBook = new JTextField(); addPublisherBook = new JTextField();
        addAuthorArticle = new JTextField(); addTitleArticle = new JTextField(); addYearArticle = new JTextField(); addJournalArticle = new JTextField(); addDOIArticle = new JTextField();
        addAuthorReport = new JTextField(); addTitleReport = new JTextField(); addYearReport = new JTextField(); addInstitutionReport = new JTextField();
        removeBookKey = new JTextField(); removeArticleKey = new JTextField(); removeReportKey = new JTextField();
        //Tabs
        JTabbedPane menu = new JTabbedPane();
        /**
         * Info
         */
        JPanel info = new JPanel();//New panel

        GridBagLayout gridBagLayout = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();

        info.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel infoLabel = new JLabel("System Tools");
        infoLabel.setHorizontalAlignment(infoLabel.CENTER);
        info.add(infoLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        TextArea infoText = new TextArea();
        infoText.setText("""
                Use the tabs panel to navigate.

                1. Load a file to system.
                2. Save system contents to file.
                3. Add publication to system.
                4. Remove publication from system.
                5. Display system contents.

                Close the window to exit.""");
        infoText.setEnabled(true);
        infoText.setEditable(false);
        info.add(infoText,gbc);

        menu.addTab("Info", null, info);//Add panel to tab
        /**
         * Load
         */
        JPanel load = new JPanel();//New panel

        load.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel loadLabel = new JLabel("Load Bibliography");
        loadLabel.setHorizontalAlignment(loadLabel.CENTER);
        load.add(loadLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        loadText = new TextArea();
        loadText.setText("Enter a file name to load contents...");
        loadText.setEnabled(true);
        loadText.setEditable(false);
        load.add(loadText,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        loadInput.setColumns(30);
        load.add(loadInput,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        loadButton = new JButton("Load");
        load.add(loadButton,gbc);

        menu.addTab("Load", null, load);//Add panel to tab
        /**
         * Save
         */
        JPanel save = new JPanel();//New panel

        save.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel saveLabel = new JLabel("Save Bibliography");
        saveLabel.setHorizontalAlignment(saveLabel.CENTER);
        save.add(saveLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        saveText = new TextArea();
        saveText.setText("Enter a file name to save contents...");
        saveText.setEnabled(true);
        saveText.setEditable(false);
        save.add(saveText,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        saveInput.setColumns(30);
        save.add(saveInput,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        saveButton = new JButton("Save");
        save.add(saveButton,gbc);

        menu.addTab("Save", null, save);//Add panel to tab
        /**
         * Add
         */
        JPanel addTo = new JPanel();//New panel

        addTo.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel addLabel = new JLabel("Add Bibliography");
        addLabel.setHorizontalAlignment(addLabel.CENTER);
        addTo.add(addLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        addText = new TextArea();
        addText.setText("""
                Publication types.

                1. Book.
                2. Article.
                3. Report.

                Use the tabs panel to navigate.""");
        addText.setEnabled(true);
        addText.setEditable(false);
        addTo.add(addText,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 2;
        addType = new JTabbedPane();
        addTo.add(addType,gbc);
        /*
         * Add tabs
         */
        //Book
        JPanel addBook = new JPanel();//New panel

        addBook.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel addBookLabel = new JLabel("Add Book");
        addBookLabel.setHorizontalAlignment(addBookLabel.CENTER);
        addBook.add(addBookLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        JLabel authorBook = new JLabel("Author");
        authorBook.setHorizontalAlignment(authorBook.LEFT);
        addBook.add(authorBook,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        addAuthorBook.setColumns(30);
        addBook.add(addAuthorBook,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        JLabel titleBook = new JLabel("Title");
        titleBook.setHorizontalAlignment(titleBook.LEFT);
        addBook.add(titleBook,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        addTitleBook.setColumns(30);
        addBook.add(addTitleBook,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        JLabel yearBook = new JLabel("Year");
        yearBook.setHorizontalAlignment(yearBook.LEFT);
        addBook.add(yearBook,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        addYearBook.setColumns(30);
        addBook.add(addYearBook,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        JLabel publisherBook = new JLabel("Publisher   ");//3 spaces
        publisherBook.setHorizontalAlignment(publisherBook.LEFT);
        addBook.add(publisherBook,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        addPublisherBook.setColumns(30);
        addBook.add(addPublisherBook,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        addBookButton = new JButton("Add");
        addBook.add(addBookButton,gbc);

        addType.addTab("Book", null, addBook);//Add panel to tab
        /*
         * Article
         */
        JPanel addArticle = new JPanel();//New panel

        addArticle.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel addArticleLabel = new JLabel("Add Article");
        addArticleLabel.setHorizontalAlignment(addArticleLabel.CENTER);
        addArticle.add(addArticleLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        JLabel authorArticle = new JLabel("Author");
        authorArticle.setHorizontalAlignment(authorArticle.LEFT);
        addArticle.add(authorArticle,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        addAuthorArticle.setColumns(30);
        addArticle.add(addAuthorArticle,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        JLabel titleArticle = new JLabel("Title");
        titleArticle.setHorizontalAlignment(titleArticle.LEFT);
        addArticle.add(titleArticle,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        addTitleArticle.setColumns(30);
        addArticle.add(addTitleArticle,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        JLabel yearArticle = new JLabel("Year");
        yearArticle.setHorizontalAlignment(yearArticle.LEFT);
        addArticle.add(yearArticle,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        addYearArticle.setColumns(30);
        addArticle.add(addYearArticle,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        JLabel journalArticle = new JLabel("Journal   ");//3 spaces
        journalArticle.setHorizontalAlignment(journalArticle.LEFT);
        addArticle.add(journalArticle,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        addJournalArticle.setColumns(30);
        addArticle.add(addJournalArticle,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        JLabel doiArticle = new JLabel("Doi");//3 spaces
        doiArticle.setHorizontalAlignment(doiArticle.LEFT);
        addArticle.add(doiArticle,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        addDOIArticle.setColumns(30);
        addArticle.add(addDOIArticle,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 6;
        gbc.gridwidth = 1;
        addArticleButton = new JButton("Add");
        addArticle.add(addArticleButton,gbc);

        addType.addTab("Article", null, addArticle);//Add panel to tab
        /*
         * Add tabs
         */
        //Report
        JPanel addReport = new JPanel();//New panel

        addReport.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel addReportLabel = new JLabel("Add Report");
        addReportLabel.setHorizontalAlignment(addReportLabel.CENTER);
        addReport.add(addReportLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        JLabel authorReport = new JLabel("Author");
        authorReport.setHorizontalAlignment(authorReport.LEFT);
        addReport.add(authorReport,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        addAuthorReport.setColumns(30);
        addReport.add(addAuthorReport,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        JLabel titleReport = new JLabel("Title");
        titleReport.setHorizontalAlignment(titleReport.LEFT);
        addReport.add(titleReport,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        addTitleReport.setColumns(30);
        addReport.add(addTitleReport,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        JLabel yearReport = new JLabel("Year");
        yearReport.setHorizontalAlignment(yearReport.LEFT);
        addReport.add(yearReport,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        addYearReport.setColumns(30);
        addReport.add(addYearReport,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        JLabel institutionReport = new JLabel("Institution   ");//3 spaces
        institutionReport.setHorizontalAlignment(institutionReport.LEFT);
        addReport.add(institutionReport,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        addInstitutionReport.setColumns(30);
        addReport.add(addInstitutionReport,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        addReportButton = new JButton("Add");
        addReport.add(addReportButton,gbc);

        addType.addTab("Report", null, addReport);//Add panel to tab

        menu.addTab("Add", null, addTo);//Add panel to tab
        /*
         * End tabs
         */
        /**
         * Remove
         */
        JPanel remove = new JPanel();//New panel

        remove.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel removeLabel = new JLabel("Remove Bibliography");
        removeLabel.setHorizontalAlignment(removeLabel.CENTER);
        remove.add(removeLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        removeText = new TextArea();
        removeText.setText("""
                Publication types.

                1. Book.
                2. Article.
                3. Report.

                Use the tabs panel to navigate.""");
        removeText.setEnabled(true);
        removeText.setEditable(false);
        remove.add(removeText,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 2;
        removeType = new JTabbedPane();
        remove.add(removeType,gbc);
        /*
         * Add tabs
         */
        //Book
        JPanel removeBook = new JPanel();//New panel

        removeBook.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel removeBookLabel = new JLabel("Remove Book");
        removeBookLabel.setHorizontalAlignment(removeBookLabel.CENTER);
        removeBook.add(removeBookLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        JLabel citeKeyBook = new JLabel("Citation key   ");//3 spaces
        citeKeyBook.setHorizontalAlignment(citeKeyBook.LEFT);
        removeBook.add(citeKeyBook,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        removeBookKey.setColumns(30);
        removeBook.add(removeBookKey,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        removeBookButton = new JButton("Remove");
        removeBook.add(removeBookButton,gbc);

        removeType.addTab("Book", null, removeBook);//Add panel to tab
        /*
         * Add tabs
         */
        //Article
        JPanel removeArticle = new JPanel();//New panel

        removeArticle.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel removeArticleLabel = new JLabel("Remove Article");
        removeArticleLabel.setHorizontalAlignment(removeArticleLabel.CENTER);
        removeArticle.add(removeArticleLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        JLabel citeKeyArticle = new JLabel("Citation key   ");//3 spaces
        citeKeyArticle.setHorizontalAlignment(citeKeyArticle.LEFT);
        removeArticle.add(citeKeyArticle,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        removeArticleKey.setColumns(30);
        removeArticle.add(removeArticleKey,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        removeArticleButton = new JButton("Remove");
        removeArticle.add(removeArticleButton,gbc);

        removeType.addTab("Article", null, removeArticle);//Add panel to tab
        /*
         * Add tabs
         */
        //Report
        JPanel removeReport = new JPanel();//New panel

        removeReport.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel removeReportLabel = new JLabel("Remove Report");
        removeReportLabel.setHorizontalAlignment(removeReportLabel.CENTER);
        removeReport.add(removeReportLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        JLabel citeKeyReport = new JLabel("Citation key   ");//3 spaces
        citeKeyReport.setHorizontalAlignment(citeKeyReport.LEFT);
        removeReport.add(citeKeyReport,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        removeReportKey.setColumns(30);
        removeReport.add(removeReportKey,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        removeReportButton = new JButton("Remove");
        removeReport.add(removeReportButton,gbc);

        removeType.addTab("Report", null, removeReport);//Add panel to tab

        menu.addTab("Remove", null, remove);//Add panel to tab
        /**
         * Display
         */
        JPanel display = new JPanel();//New panel

        display.setLayout(gridBagLayout);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel displayLabel = new JLabel("Display Bibliography");
        displayLabel.setHorizontalAlignment(displayLabel.CENTER);
        display.add(displayLabel,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 1;
        displayText = new TextArea();
        displayText.setText("Contents will be displayed below in harvard format..."+"\n");
        displayText.setEnabled(true);
        displayText.setEditable(false);
        display.add(displayText,gbc);

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 2;
        displayButton = new JButton("Display");
        display.add(displayButton,gbc);

        menu.addTab("Display", null, display);//Add panel to tab

        //MainFrame
        mainFrame.getContentPane().add(menu, BorderLayout.CENTER);

    }

    /**
     *
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        String buttonClicked = e.getActionCommand();

        switch (buttonClicked) {
            case "Load": {

                if(loadInput.getText().equals("")){
                    loadText.setText(loadText.getText() + "\n" + "\n" + "ERROR: Value cant be empty, try again!");
                }
                else {
                    ConcreteFactory loadBibliography = new ConcreteFactory();
                    File fileLoaded = new File(loadInput.getText());
                    try {
                        FileReader fileReader = new FileReader(fileLoaded);
                        BufferedReader bufferedReader = new BufferedReader(fileReader);

                        loadBibliography.ReceiveFileLoad(bufferedReader);

                        bufferedReader.close();
                        loadText.setText(loadText.getText() + "\n" + "\n" + "ALERT: Load successful!");
                    } catch (IOException ioe) {
                        loadText.setText(loadText.getText() + "\n" + "\n" + "ERROR: Unable to process this request, try again!");
                    }
                }
                break;
            }
            case "Save": {

                if(saveInput.getText().equals("")){
                    saveText.setText(saveText.getText() + "\n" + "\n" + "ERROR: Value cant be empty, try again!");
                }
                else {
                    ConcreteFactory saveBibliography = new ConcreteFactory();
                    File fileLoaded = new File(saveInput.getText());
                    try {
                        FileWriter fileWriter = new FileWriter(fileLoaded);
                        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

                        saveBibliography.ReceiveFileSave(bufferedWriter);
                        saveBibliography.SaveContents(database.getPublications());

                        bufferedWriter.close();
                        saveText.setText(saveText.getText() + "\n" + "\n" + "ALERT: Save successful!");
                    } catch (IOException ioe) {
                        saveText.setText(saveText.getText() + "\n" + "\n" + "ERROR: Unable to process this request, try again!");
                    }
                }
                break;
            }
            case "Add":

                if (addType.getSelectedIndex() == 0) {

                    ConcreteFactory newPublication = new ConcreteFactory();

                    Book newBook = new Book();
                    newPublication.InputContents(newBook);

                    if(newPublication.newEntry){

                        database.getPublications().add(newBook);

                    }
                }
                else if (addType.getSelectedIndex() == 1) {

                    ConcreteFactory newPublication = new ConcreteFactory();

                    Article newArticle = new Article();
                    newPublication.InputContents(newArticle);

                    if(newPublication.newEntry){

                        database.getPublications().add(newArticle);

                    }
                }
                else if (addType.getSelectedIndex() == 2) {

                    ConcreteFactory newPublication = new ConcreteFactory();

                    Report newReport = new Report();
                    newPublication.InputContents(newReport);

                    if(newPublication.newEntry){

                        database.getPublications().add(newReport);

                    }
                }
                else {
                    addText.setText(addText.getText() + "\n" + "\n" + "ERROR: Unable to process this request, try again!");
                }
                break;
            case "Remove":

                ArrayList<Publication> search = new ArrayList<>(database.getPublications());
                boolean found = false;

                if (removeType.getSelectedIndex() == 0) {

                    if(removeBookKey.getText().equals("")){
                        removeText.setText(removeText.getText() + "\n" + "\n" + "ERROR: Value cant be empty, try again!");
                    }
                    else {
                        for (Publication elements : search) {

                            if (elements.getCitekey().equals(removeBookKey.getText())) {

                                database.getPublications().remove(elements);
                                found = true;

                            }
                        }
                        if (found) {
                            removeText.setText(removeText.getText() + "\n" + "\n" + "ALERT: Book removed!");
                            removeBookKey.setText(null);
                        } else
                        {
                            removeText.setText(removeText.getText() + "\n" + "\n" + "ERROR: No book found, try again!");
                        }
                    }
                } else if (removeType.getSelectedIndex() == 1) {

                    if(removeArticleKey.getText().equals("")){
                        removeText.setText(removeText.getText() + "\n" + "\n" + "ERROR: Value cant be empty, try again!");
                    }
                    else {
                        for (Publication elements : search) {

                            if (elements.getCitekey().equals(removeArticleKey.getText())) {

                                database.getPublications().remove(elements);
                                found = true;

                            }
                        }
                        if (found) {
                            removeText.setText(removeText.getText() + "\n" + "\n" + "ALERT: Article removed!");
                            removeArticleKey.setText(null);
                        } else
                        {
                            removeText.setText(removeText.getText() + "\n" + "\n" + "ERROR: No article found, try again!");
                        }
                    }
                } else if (removeType.getSelectedIndex() == 2) {

                    if (removeReportKey.getText().equals("")) {
                        removeText.setText(removeText.getText() + "\n" + "\n" + "ERROR: Value cant be empty, try again!");
                    }
                    else {
                        for (Publication elements : search) {

                            if (elements.getCitekey().equals(removeReportKey.getText())) {

                                database.getPublications().remove(elements);
                                found = true;

                            }
                        }
                        if (found) {
                            removeText.setText(removeText.getText() + "\n" + "\n" + "ALERT: Report removed!");
                            removeReportKey.setText(null);
                        } else {
                            removeText.setText(removeText.getText() + "\n" + "\n" + "ERROR: No report found, try again!");
                        }
                    }
                }
                break;
            case "Display":

                ConcreteFactory displayBibliography = new ConcreteFactory();
                displayText.setText(displayText.getText() + "\n" + "Publications..." + "\n");
                displayBibliography.DisplayContents(database.getPublications());
                break;
        }
    }

    /**
     *
     * @param args
     */
    public static void main(String[] args){

        ArrayList<Publication> testList = new ArrayList<>();

        Book newBook = new Book();
        newBook.setAuthor("Hawking, Stephen");newBook.setTitle("A Brief History of Time: From the Big Bang to Black Holes");newBook.setYear(1988);newBook.setPublisher("Bantam");newBook.setCiteKey("hawking1988");

        Article newArticle = new Article();
        newArticle.setAuthor("Gamma, Erich and Helm, Richard and Johnson, Ralph and Vlissides, John");newArticle.setTitle("Design Patterns: Abstraction and Reuse of Object-Oriented Design");newArticle.setYear(1993);newArticle.setJournal("ECOOP' 93 --- Object-Oriented Programming");
        newArticle.setDOI("10.1007/3-540-47910-4_21");newArticle.setCiteKey("gamma93ecoop");

        Report newReport = new Report();
        newReport.setAuthor("Cummins, Ronan and O'Riordan, Colm");newReport.setTitle("Evolving, Analysing and Improving Global Term-Weighting Schemes in Information Retrieval");newReport.setYear(2004);
        newReport.setInstitution("National University of Ireland, Galway");newReport.setCiteKey("Cummins:2004:071204");

        testList.add(newBook);
        testList.add(newArticle);
        testList.add(newReport);

        MenuGUI menuGUI = new MenuGUI();

        menuGUI.AddTestList(testList);

        createWindow();

        loadButton.addActionListener(menuGUI);
        saveButton.addActionListener(menuGUI);
        addBookButton.addActionListener(menuGUI);
        addArticleButton.addActionListener(menuGUI);
        addReportButton.addActionListener(menuGUI);
        removeBookButton.addActionListener(menuGUI);
        removeArticleButton.addActionListener(menuGUI);
        removeReportButton.addActionListener(menuGUI);
        displayButton.addActionListener(menuGUI);
    }
}
