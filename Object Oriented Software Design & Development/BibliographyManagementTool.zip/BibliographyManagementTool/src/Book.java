/**
 * Subclass of Publication
 * Contains unique data members w/ getters and setters
 * Contains type safe process methods used for book items
 */
public class Book extends Publication {

    //Data members
    private String publisher;

    //Setter
    public void setPublisher(String publisher) {

        this.publisher=publisher;
    }
    //Getter
    public String getPublisher() {

        return publisher;
    }
    //Returns element to Create method
    @Override
    protected void ProcessDisplay(ConcreteFactory displayBookItem) {
        displayBookItem.DisplayBookItem(this);
    }
    @Override
    protected void ProcessInput(ConcreteFactory newBookInput){
        newBookInput.InputBookItem(this);
    }
    @Override
    protected void ProcessSave(ConcreteFactory saveBookItem) {
        saveBookItem.SaveBookItem(this);
    }
    @Override
    protected void ProcessLoad(ConcreteFactory loadBookItem) {
        loadBookItem.LoadBookItem(this);
    }
}
