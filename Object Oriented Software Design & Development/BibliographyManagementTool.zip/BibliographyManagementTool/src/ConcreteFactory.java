import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;

public class ConcreteFactory implements Control, Comparator<Publication> {

    //Load file with bibTex contents and store to arrayList

    //Data members
    private final char quote = '"';
    private final char comma = ',';
    private final String doiPrefix = "https://doi.org/";

    boolean newEntry = false;

    BufferedWriter writeContents;

    /**
     * Method receives and assigns file - used with save methods
     * @param bufferedReader
     */
    public void ReceiveFileLoad(BufferedReader bufferedReader){

    }
    /**
     * Method receives and assigns file - used with save methods
     * @param bufferedWriter
     */
    public void ReceiveFileSave(BufferedWriter bufferedWriter){
        writeContents = bufferedWriter;
    }
    /**
     * Forwards elements of array to each subclass ProcessItem method
     * @param publications
     */
    public void SaveContents(ArrayList<Publication> publications) {
        publications.sort(new ConcreteFactory());
        for (Publication elements : publications) {
            elements.ProcessSave(this);
        }
    }
    /**
     * Forwards the input request to the correct methods
     * @param publication
     */
    public void InputContents(Publication publication) {
        publication.ProcessInput(this);

    }
    /**
     * Forwards elements of array to each subclass ProcessItem method
     * @param publications
     */
    public void DisplayContents(ArrayList<Publication> publications) {
        publications.sort(new ConcreteFactory());
        for (Publication elements : publications) {
            elements.ProcessDisplay(this);
        }
    }
    /**
     * Method compares list objects by year - utilized in DisplayContents method
     * Descending order - Most recent year firs
     * @param p1
     * @param p2
     * @return
     */
    @Override
    public int compare(Publication p1, Publication p2) {
        return  p2.getYear() - p1.getYear();
    }
    /**
     * Display book
     * @param displayBook
     */
    @Override
    public void DisplayBookItem(Book displayBook) {

        //GUI
        MenuGUI.displayText.setText(MenuGUI.displayText.getText() + "\n" +
                "@book(" + displayBook.getCitekey() + ")" + "\n" +
                displayBook.getAuthor() + ". " + "(" + displayBook.getYear() + "). "
                + displayBook.getTitle() + ". " + displayBook.getPublisher() + "." + "\n");
    }
    /**
     * Display article
     * @param displayArticle
     */
    @Override
    public void DisplayArticleItem(Article displayArticle) {

        //GUI
        MenuGUI.displayText.setText(MenuGUI.displayText.getText() + "\n" +
                "@article(" + displayArticle.getCitekey() + ")" + "\n" +
                displayArticle.getAuthor() + ". " + "(" + displayArticle.getYear() + "). "
                + displayArticle.getTitle() + ". " + displayArticle.getJournal() + ". " +
                doiPrefix + displayArticle.getDOI() + "." + "\n");
    }
    /**
     * Display report
     * @param displayReport
     */
    @Override
    public void DisplayReportItem(Report displayReport) {

        //GUI
        MenuGUI.displayText.setText(MenuGUI.displayText.getText() + "\n" +
                "@report(" + displayReport.getCitekey() + ")" + "\n" +
                displayReport.getAuthor() + ". " + "(" + displayReport.getYear() + "). "
                + displayReport.getTitle() + ". " + displayReport.getInstitution() + "." + "\n");
    }
    /**
     * Write book item to file
     * @param saveBook
     */
    @Override
    public void SaveBookItem(Book saveBook) {
        try{
            writeContents.write("@book{" + saveBook.getCitekey() + comma + "\n" +
                    "author    = " + quote + saveBook.getAuthor() + quote + comma + "\n" +
                    "title     = " + quote + saveBook.getTitle() + quote + comma + "\n" +
                    "year      = " + saveBook.getYear() + comma + "\n" +
                    "publisher = " + quote +  saveBook.getPublisher() + quote + "\n");
            writeContents.write("\n");//New line

        }catch (IOException e) {
            System.out.println("ERROR: Failed to write book item to file!");
        }
    }
    /**
     * Write article item to file
     * @param saveArticle
     */
    @Override
    public void SaveArticleItem(Article saveArticle) {
        try{
            writeContents.write("@article{" + saveArticle.getCitekey() + "\n" +
                    "author=" + quote + saveArticle.getAuthor() + quote + comma + "\n" +
                    "title=" + quote + saveArticle.getTitle() + quote + comma + "\n" +
                    "year=" + quote + saveArticle.getYear() + quote + comma + "\n" +
                    "journal=" + quote + saveArticle.getJournal() + quote + comma + "\n" +
                    "doi=" + quote + doiPrefix + saveArticle.getDOI() + quote + "\n");
            writeContents.write("\n");//New line

        }catch (IOException e) {
            System.out.println("ERROR: Failed to write article item to file!");
        }
    }
    /**
     * Write report item to file
     * @param saveReport
     */
    @Override
    public void SaveReportItem(Report saveReport) {
        try{
            writeContents.write("@report{" + saveReport.getCitekey() + comma + "\n" +
                    "author = " + quote +  saveReport.getAuthor() + quote + comma + "\n" +
                    "title = " + quote +  saveReport.getTitle() + quote + comma + "\n" +
                    "year = " + quote +  saveReport.getYear() + quote + comma + "\n" +
                    "institution = " + quote +  saveReport.getInstitution() + quote + "\n");
            writeContents.write("\n");//New line

        }catch (IOException e) {
            System.out.println("ERROR: Failed to write report item to file!");
        }
    }
    /**
     * Get book input fields
     * @param inputBook
     */
    @Override
    public void InputBookItem(Book inputBook) {

        try {

            inputBook.setAuthor(MenuGUI.addAuthorBook.getText());
            inputBook.setTitle(MenuGUI.addTitleBook.getText());
            inputBook.setYear(Integer.parseInt(MenuGUI.addYearBook.getText()));
            inputBook.setPublisher(MenuGUI.addPublisherBook.getText());

            String[] splitName = inputBook.getAuthor().toLowerCase().split(",");

            inputBook.setCiteKey(splitName[0] + inputBook.getYear());

            newEntry=true;
            MenuGUI.addText.setText(MenuGUI.addText.getText() + "\n" + "\n" + "ALERT: Book added!");

            MenuGUI.addAuthorBook.setText(null);
            MenuGUI.addTitleBook.setText(null);
            MenuGUI.addYearBook.setText(null);
            MenuGUI.addPublisherBook.setText(null);

        } catch (Exception error) {
            MenuGUI.addText.setText(MenuGUI.addText.getText() + "\n" + "\n" + "ERROR: Incomplete form and/or Incorrect input type, try again!");
        }
    }
    /**
     * Get article input fields
     * @param inputArticle
     */
    @Override
    public void InputArticleItem(Article inputArticle) {

        try {

            inputArticle.setAuthor(MenuGUI.addAuthorArticle.getText());
            inputArticle.setTitle(MenuGUI.addTitleArticle.getText());
            inputArticle.setYear(Integer.parseInt(MenuGUI.addYearArticle.getText()));
            inputArticle.setJournal(MenuGUI.addJournalArticle.getText());
            inputArticle.setDOI(MenuGUI.addDOIArticle.getText());

            String[] splitName = inputArticle.getAuthor().toLowerCase().split(",");
            String[] splitJournal = inputArticle.getJournal().split(" ");

            inputArticle.setCiteKey(splitName[0] + splitJournal[1] + splitJournal[0] + inputArticle.getYear());

            newEntry=true;
            MenuGUI.addText.setText(MenuGUI.addText.getText() + "\n" + "\n" + "ALERT: Article added!");

            MenuGUI.addAuthorArticle.setText(null);
            MenuGUI.addTitleArticle.setText(null);
            MenuGUI.addYearArticle.setText(null);
            MenuGUI.addJournalArticle.setText(null);
            MenuGUI.addDOIArticle.setText(null);

        } catch (Exception error) {
            MenuGUI.addText.setText(MenuGUI.addText.getText() + "\n" + "\n" + "ERROR: Incomplete form and/or Incorrect input type, try again!");
        }
    }
    /**
     * Get report input fields
     * @param inputReport
     */
    @Override
    public void InputReportItem(Report inputReport) {

        try {

            inputReport.setAuthor(MenuGUI.addAuthorReport.getText());
            inputReport.setTitle(MenuGUI.addTitleReport.getText());
            inputReport.setYear(Integer.parseInt(MenuGUI.addYearReport.getText()));
            inputReport.setInstitution(MenuGUI.addInstitutionReport.getText());

            String[] splitName = inputReport.getAuthor().split(",");

            inputReport.setCiteKey(splitName[0] + ":" + inputReport.getYear());

            newEntry=true;
            MenuGUI.addText.setText(MenuGUI.addText.getText() + "\n" + "\n" + "ALERT: Report added!");

            MenuGUI.addAuthorReport.setText(null);
            MenuGUI.addTitleReport.setText(null);
            MenuGUI.addYearReport.setText(null);
            MenuGUI.addInstitutionReport.setText(null);

        } catch (Exception error) {
            MenuGUI.addText.setText(MenuGUI.addText.getText() + "\n" + "\n" + "ERROR: Incomplete form and/or Incorrect input type, try again!");
        }
    }
    /**
     * Read book item from file
     * @param book
     */
    @Override
    public void LoadBookItem(Book book) {

    }

    /**
     * Read article item from file
     * @param article
     */
    @Override
    public void LoadArticleItem(Article article) {

    }
    /**
     * Read report item from file
     * @param report
     */
    @Override
    public void LoadReportItem(Report report) {

    }
}
