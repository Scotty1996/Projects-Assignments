//Create array, global to store the original timestamp for comment modification
var timeArray = new Array();
//Create array, global so we can keep adding comments
var commentArray = new Array();
//Create array, global so we can like/dislike
var commentVote = new Array();
function Comment() {
    //Init handle and comment
    var like = 0;
    var dislike = 0;
    var voteCount = {upVote: like, downVote: dislike};
    commentVote.push(voteCount);

    //Get time
    var postDate = Date.now();
    //Move postDate into timeArray, index 0 is the same value as index 0 in commentArray
    var newTime = {time: postDate};
    timeArray.push(newTime);

    //Init handle and comment
    var handle = null;
    var comment = null;

    var form = document.getElementById('formSection');
    var handleInput = form.elements.enterHandle.value;
    var commentInput = form.elements.enterComment.value;

    //Create newComment
    var newComment = {time: postDate, handle: handleInput, comment: commentInput};
    //Add into array
    commentArray.push(newComment);

    //Call
    Refresh();
}
function Like(){
    //Update table with like
    //Loop through table rows to find which button was pressed
    //Used Hover as the selctor since clicking involves hovering
    //Since the table adds from index 0 and pushes new comments,
    //up one index, the indexes would missmtach the position of a value,
    //eg table index 0,1,2
    //While the other arrays values indexes would be 2,1,0
    //So I search the table to find what like/dislike button was clicked,
    //at which table index while also using an inverse count of the tables indexes,
    //to add the like to the correct comment
    var table = document.getElementById("commentTable").getElementsByTagName("tbody")[0]
        .getElementsByTagName("tr");

    var inverseCount = table.length;
    for(var l = 0; l < table.length; l++) {
        inverseCount--;
        if(table[l].matches(":hover")) {
            commentVote[inverseCount].upVote++;
        }

    }
    //Call
    Refresh();
}
function Dislike(){
    var table = document.getElementById("commentTable").getElementsByTagName("tbody")[0]
        .getElementsByTagName("tr");

    var inverseCount = table.length;
    for(var l = 0; l < table.length; l++) {
        inverseCount--;
        if(table[l].matches(":hover")) {
            commentVote[inverseCount].downVote++;
        }

    }
    //Call
    Refresh();
}
function Refresh(){
    //Refresh table
    for (var i = 0; i < commentArray.length; i++) {

        var timePosted = commentArray[i].time;

        //Get same index from timeArray
        var originalTime = timeArray[i].time;
        //Set to 0 to avoid bugs
        timePosted = 0;
        //Assigns original timestamp back
        timePosted = originalTime;

        //Get current time and formate
        var timePassed = Date.now();
        var seconds = (timePassed / 1000) - (timePosted / 1000);
        var minutes = ((timePassed / 1000) / 60) - ((timePosted / 1000) / 60);
        var hours = (((timePassed / 1000) / 60) / 60) - (((timePosted / 1000) / 60) / 60);
        var days = ((((timePassed / 1000) / 60) / 60) / 24) - ((((timePosted / 1000) / 60) / 60) / 24);

        //Used Math.round() to remove decimal places and round up/down value to nearest int
        //Just now
        if (seconds < 10) {
            commentArray[i].time = "Just now";
        }
        //Seconds
        else if (seconds > 10 && seconds < 60) {
            var sec = Math.round(seconds);
            commentArray[i].time = sec + "s ago";
        }
        //Minutes
        else if (seconds > 60 && minutes < 60) {
            var min = Math.round(minutes);
            commentArray[i].time = min + "m ago";
        }
        //Hours
        else if (minutes > 60 && hours < 24) {
            var hr = Math.round(hours);
            commentArray[i].time = hr + "h ago";
        }
        //Days
        else if (hours >= 24 && days <= 30) {
            var d = Math.round(days);
            commentArray[i].time = d + "d ago"
        }
        //Modified code from notes on blackboard
        //Wanted the table to print the most recent comments on top
        //We make an invisible/empty table head since we only require id
        var sHTML = "<table class='table' id='commentTable'><tbody>\n";
        sHTML += "</tbody></table>";
        displayComment.innerHTML = sHTML;

        for(var j = 0; j < commentArray.length; j++) {

            //Find table element with id
            var table = document.getElementById("commentTable");
            //Create row
            var row1 = table.insertRow(0);
            //Insert new cells
            var cell1 = row1.insertCell(0);
            //Add
            cell1.innerHTML = "@" + commentArray[j].handle + ": " + commentArray[j].comment +
                "<br>" + "Posted: " + commentArray[j].time + "<br>" +
                " " + "Likes: " + commentVote[j].upVote + " - "
                + "Dislikes: " + commentVote[j].downVote + "<br>" +
                " " + "<input id='like' type='submit' value='Like' onclick='Like(); return false;' style='color: green'></input>" +
                "" +  "<input id='dislike' type='submit' value='Dislike' onclick='Dislike(); return false;' style='color: red'></input>"
        }
    }
    //Resets the form input
    document.getElementById("formSection").reset();
}
function ClearForm(){
    //Resets the form input
    document.getElementById("formSection").reset();
}
//Change color of button
function MouseOver() {
    //Check which button is on hover
    if(document.getElementById("post").matches(":hover")){
        document.getElementById("post").style.color = "blue";
    }
    if(document.getElementById("clear").matches(":hover")){
        document.getElementById("clear").style.color = "blue";
    }
    if(document.getElementById("refresh").matches(":hover")){
        document.getElementById("refresh").style.color = "blue";
    }
}
//Change color of button
function MouseOut() {
    //Check which button to reset to black
    if (document.getElementById("post").matches(":hover") == false) {
        document.getElementById("post").style.color = "black";
    }
    if (document.getElementById("clear").matches(":hover") == false) {
        document.getElementById("clear").style.color = "black";
    }
    if (document.getElementById("refresh").matches(":hover") == false) {
        document.getElementById("refresh").style.color = "black";
    }
}
function tableColor() {
//Thead
    var thead = document.getElementById("table1").getElementsByTagName("thead")[0];
    thead.className = "black";
//Changes row color based on results
//Works by getting table tag td's value and checking against string
    var rows = document.getElementById("table1").getElementsByTagName("tbody")[0]
        .getElementsByTagName("tr");

    for (var i = 0; i < rows.length; i++) {

        cellValue = rows[i].getElementsByTagName("td")

        if (cellValue[3].innerHTML == "Club Win") {
            rows[i].className = "green";

        } else if (cellValue[3].innerHTML == "Club Loss") {
            rows[i].className = "red";

        } else if (cellValue[3].innerHTML == "Draw") {
            rows[i].className = "yellow";

        } else {
            rows[i].className = "white";
        }
    }
}
